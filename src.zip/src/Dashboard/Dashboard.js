import NavbarD from "./navbarD/navbarD";
import Navbar1 from "./navbarD/navbar2";
import Body from "./BodyD/Body";
function Dashboard(){
return (
<div>
<NavbarD></NavbarD>
<Navbar1></Navbar1>
<Body></Body>
</div>
);
}
export default Dashboard;